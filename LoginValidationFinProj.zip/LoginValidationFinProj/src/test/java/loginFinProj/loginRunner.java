package loginFinProj;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/resources/loginFeature"},glue= {"loginFinProj"})
public class loginRunner {

}

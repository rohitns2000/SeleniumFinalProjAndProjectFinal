package loginFinProj;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.LoginValidationPageFactory;

public class LoginStepDefinition {
	private WebDriver driver;
	private LoginValidationPageFactory lvpf;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
		"D:\\Users\\rsammanw\\Desktop\\Selenium ChromeDriver and tutscloud\\chromedriver_win32\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^User is on 'login' page$")
	public void user_is_on_login_page() throws Throwable {
	    driver.get("http://localhost:4200");
	    lvpf = new LoginValidationPageFactory(driver);
	}

	@When("^User leaves email field empty$")
	public void user_leaves_email_field_empty() throws Throwable {
		lvpf.setUsername("");
		lvpf.setPassword("");;
	    
	}

	@Then("^display 'Enter valid EmailId'$")
	public void display_Enter_valid_EmailId() throws Throwable {
		String expected = "Enter valid EmailId";
		String actual = lvpf.getInvalidU().getText();
		Assert.assertEquals(expected, actual);
		driver.close();
	    
	}

	@When("^User leaves password field empty$")
	public void user_leaves_password_field_empty() throws Throwable {
	   lvpf.setUsername("rohit@gmail.com");
	   lvpf.setPassword("");
	   lvpf.setUsername("rohit@gmail.com");;
	}

	@Then("^display 'Enter valid Password'$")
	public void display_Enter_valid_Password() throws Throwable {
		String expected = "Enter valid Password";
		String actual = lvpf.getInvalidP().getText();
		Assert.assertEquals(expected, actual);
		driver.close();
	}

	@When("^User enters invalid credentials$")
	public void user_enters_invalid_credentials() throws Throwable {
		 lvpf.setUsername("rohit@gmail.com");
		   lvpf.setPassword("rsam");
		   lvpf.setSubmitBtn();  
	}

	@Then("^display 'Invalid Login!'$")
	public void display_Invalid_Login() throws Throwable {
		Thread.sleep(5000);
		String expected = "Invalid Login!";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters valid user credentials$")
	public void user_enters_valid_user_credentials() throws Throwable {
		lvpf.setUsername("Anand@gmail.com");
		   lvpf.setPassword("apass");
		   lvpf.setSubmitBtn();
	}

	@Then("^display 'User Logged In!!!'$")
	public void display_User_Logged_In() throws Throwable {
		Thread.sleep(5000);
		String expected = "User Logged In!!!";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters valid Merchant credentials$")
	public void user_enters_valid_Merchant_credentials() throws Throwable {
		lvpf.setUsername("zat@gmail.com");
		lvpf.setPassword("zpass");
		lvpf.setSubmitBtn();
	    
	}

	@Then("^display 'Merchant Logged In!!!'$")
	public void display_Merchant_Logged_In() throws Throwable {
		Thread.sleep(5000);
		String expected = "Merchant Logged In!!!";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^User enters valid Admin credentials$")
	public void user_enters_valid_Admin_credentials() throws Throwable {
		lvpf.setUsername("rohit@gmail.com");
		lvpf.setPassword("rpass");
		lvpf.setSubmitBtn();
	    
	}

	@Then("^display 'Admin Logged In!!!'$")
	public void display_Admin_Logged_In() throws Throwable {
		Thread.sleep(5000);
		String expected = "Admin Logged In!!!";
		String actual = driver.switchTo().alert().getText();
		Assert.assertEquals(expected, actual);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}

}

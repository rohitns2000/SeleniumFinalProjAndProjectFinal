package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginValidationPageFactory {
	WebDriver driver;
	
	@FindBy(id="username")
	@CacheLookup
	WebElement username;
	
	@FindBy(id="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(id="submit")
	@CacheLookup
	WebElement submitBtn;
	
	@FindBy(id="invalidU")
	@CacheLookup
	WebElement invalidU;
	
	@FindBy(id="invalidP")
	@CacheLookup
	WebElement invalidP;
	
	public WebElement getInvalidU() {
		return invalidU;
	}

	public void setInvalidU(WebElement invalidU) {
		this.invalidU = invalidU;
	}

	public WebElement getInvalidP() {
		return invalidP;
	}

	public void setInvalidP(WebElement invalidP) {
		this.invalidP = invalidP;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getSubmitBtn() {
		return submitBtn;
	}

	public void setSubmitBtn() {
		this.submitBtn.click();;
	}

	//Initializing Elements
	public LoginValidationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	

}

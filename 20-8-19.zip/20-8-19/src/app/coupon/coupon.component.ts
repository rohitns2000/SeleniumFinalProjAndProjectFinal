import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/data.service';

export class coupon{
  constructor(
    public couponid:number,
    public startDate:Date,
    public endDate:Date,
    public couponName:string,
    public userid:number,
    public discount:number
  ){}
}

@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.css']
})
export class CouponComponent implements OnInit {

  cu:coupon
  boolDate:boolean=false
  boolDiscount:boolean=false

  constructor(private service:DataService) { 
  }

  ngOnInit() {
    this.cu = new coupon(null,null,null,"",null,null)
  }

  checkDateValidation(startDate,endDate){
    if(startDate > endDate)
    {
      return false
    }
    else{
      return true
    }
  }

  checkDiscount(discount){
    if(discount > 100)
    {
      return false
    }
    else{
      return true
    }
  }

  addCoupon(){
    alert(this.cu.couponid+" "+this.cu.startDate+" "+this.cu.endDate+" "+this.cu.couponName+" "+this.cu.userid+" "+this.cu.discount)
    this.boolDate = this.checkDateValidation(this.cu.startDate,this.cu.endDate)
    this.boolDiscount = this.checkDiscount(this.cu.discount)
    
    if(this.boolDate === true && this.boolDiscount === true)
    {
      this.service.saveCoupon(this.cu).subscribe(
        data=>{
          console.log(data)
          alert("Successfully Added!")
          window.location.reload()
        },
        error=>{
          console.log("Error...Please Try Again...")
        }
        
      )

    }
    else if (this.boolDate === false ){
      alert("Check Entered Date!")
    }
    else if (this.boolDiscount === false ){
      alert("Check Entered Discount!")
    }
    else{
      alert("")
    }
  }



}

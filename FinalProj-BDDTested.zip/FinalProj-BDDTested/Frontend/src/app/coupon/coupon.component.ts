import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/data.service';

export class coupon{
  constructor(
    public couponid:number,
    public startDate:Date,
    public endDate:Date,
    public couponName:string,
    public userid:number,
    public discount:number
  ){}
}

@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.css']
})
export class CouponComponent implements OnInit {

  cu:coupon

  constructor(private service:DataService) { }

  ngOnInit() {
    this.cu = new coupon(0,null,null,"",0,0)
  }

  addCoupon(){
    alert(this.cu.couponid+" "+this.cu.startDate+" "+this.cu.endDate+" "+this.cu.couponName+" "+this.cu.userid+" "+this.cu.discount)
    this.service.saveCoupon(this.cu).subscribe(
      data=>{
        console.log(data)
      }
    )
  }



}

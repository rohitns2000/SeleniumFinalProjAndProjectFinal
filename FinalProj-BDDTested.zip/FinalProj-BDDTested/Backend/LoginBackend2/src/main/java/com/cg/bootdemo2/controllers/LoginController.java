package com.cg.bootdemo2.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bootdemo2.entities.Admin;
import com.cg.bootdemo2.entities.Coupon;
import com.cg.bootdemo2.entities.User1;
import com.cg.bootdemo2.entities.Merchant;
import com.cg.bootdemo2.services.WalletService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class LoginController {
@Autowired WalletService service;

//Automatic populating stuffs
@GetMapping("/")
public void populate() throws ParseException {
	service.addAdmin(new Admin("rohit","rohit","rohit@gmail.com","rpass","photu"));
//	service.addAdmin(new Admin(102,"Rakesh","Rakesh"));
//	service.addAdmin(new Admin(103,"Sahu","Sahu"));
	
	service.addCustomer(new User1("Anand@gmail.com","Anand","Hi Anand","apass",98765L,"addressinHere","photuu"));
//	service.addCustomer(new User1(105,"Mug","Mug"));
//	service.addCustomer(new User1(106,"Pat","Pat"));
//	
	service.addMerchant(new Merchant("Zat","ZatL","companyhere","zat@gmail.com",98765L,"zpass","photuuu",6D,"status"));
//	service.addMerchant(new Merchant(108,"Kok","Kok"));
//	service.addMerchant(new Merchant(109,"Tut","Tut"));
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Date fromDate = sdf.parse("1992-07-26");
	Date toDate = sdf.parse("1992-09-26");
	java.sql.Date sqlDate = new java.sql.Date(fromDate.getTime());
	
	service.addCoupon(new Coupon(sqlDate,toDate,"SpringTime",102,20.00D));
}

//Finding A particular Account
@GetMapping("/find/admin/{username}/{password}")
public Admin getAccountAdmin(@PathVariable("username") String username,@PathVariable("password") String password)
{
	Admin ad = service.findAdmin(username,password); 
	System.out.println(ad);
	System.out.println(username+ " " +password);
	if(ad == null)
	{
		Admin ad1 = new Admin("","","","","");
		return ad1;
	}
	return ad;
}

//Finding A particular Account
@GetMapping("/find/customer/{username}/{password}")
public User1 getAccountCustomer(@PathVariable("username") String username,@PathVariable("password") String password)
{
	User1 ad = service.findCustomer(username,password); 
	System.out.println(ad);
	if(ad == null)
	{
		User1 ad1 = new User1("","","","",0L,"","");
		return ad1;
	}
	return ad;
}

//Finding A particular Account
@GetMapping("/find/merchant/{username}/{password}")
public Merchant getAccountMerchant(@PathVariable("username") String username,@PathVariable("password") String password)
{
	Merchant ad = service.findMerchant(username,password); 
	System.out.println(ad);
	if(ad == null)
	{
		Merchant ad1 = new Merchant("","","","",0L,"","",0D,"");
		return ad1;
	}
	return ad;
}

//for adding coupon into the database
@PostMapping("/coupon/new")
public boolean setCoupon(@RequestBody Coupon cu)
{
	Coupon cu1 = new Coupon();
	cu1.setStartDate(cu.getStartDate());
	cu1.setEndDate(cu.getEndDate());
	cu1.setCouponName(cu.getCouponName());
	cu1.setUserid(cu.getUserid());
	cu1.setDiscount(cu.getDiscount());
	service.addCoupon(cu1);
	
	return true;
	
}

//get all the coupons
@GetMapping("/coupon/findAll")
public List<Coupon> getAllCoupons()
{
	List<Coupon> lst = service.showAllCoupon();
	return lst;
}

}
